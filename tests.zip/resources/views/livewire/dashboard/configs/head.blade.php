<div>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <title>آتریو - قالب بوت استرپ 4 مدیریتی </title>
        <link rel="icon" href="{{asset('dashboard/images/favicon.ico')}}" type="image/x-icon">
        @stack('styles')
            <link href="{{asset('dashboard/css/app.min.css')}}" rel="stylesheet">
            <link href="{{asset('dashboard/js/bundles/materialize-rtl/materialize-rtl.min.css')}}" rel="stylesheet">
            <link href="{{asset('dashboard/css/style.css')}}" rel="stylesheet" />
            <link href="{{asset('dashboard/css/styles/all-themes.css')}}" rel="stylesheet" />
            <link href="{{asset('dashboard/css/custom.css')}}" rel="stylesheet" />
        @livewireStyles
    </head>
    <style>

    </style>
</div>
