<!DOCTYPE html>
<html lang="en">
<livewire:home.auth.configs.head />
<body>
{{$slot}}
<livewire:home.auth.configs.foot />
@livewireScripts
</body>
