<div>
    <div class="shop-container" style="direction: rtl" >
        <div class="row w-100">
            <div class="col-lg-3 col-sm-12">
                <div class="sidebar-profile d-flex" >
                    <img class="avatar" width="80px" height="80px" src="<?php echo e(asset('/home/images/user.png')); ?>">
                    <div class="mx-4">
                        <p class="mb-1 text-muted">مهدی اسماعیلی</p>
                        <p class="mb-1 text-muted">09193544391</p>
                        <p class="mb-1 text-muted">0372009522</p>
                    </div>
                </div>

                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.shop.category', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1763174140-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


            </div>
            <div class="col-lg-6 col-sm-12">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.shop.product', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1763174140-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>



            </div>
            <div class="col-lg-3">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.shop.basket', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1763174140-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>

    </div>
</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/shop/index.blade.php ENDPATH**/ ?>