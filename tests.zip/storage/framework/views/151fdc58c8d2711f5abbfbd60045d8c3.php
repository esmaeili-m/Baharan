<div>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('dashboard/js/bundles/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/js/bundles/multiselect/css/multi-select.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <a href="<?php echo e(route('service.create')); ?>"><button class="btn-hover btn-border-radius color-7 border-radius-custom">افزودن خدمات</button></a>
                    <a href="<?php echo e(route('service.trash')); ?>"><button class="btn-hover btn-border-radius color-8 border-radius-custom">سطل آشغال ( <?php echo e(\App\Models\Services::onlyTrashed()->count()); ?> )</button></a>

                </div>
                <div class="body table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>

                            <th>#</th>
                            <th>تصویر</th>
                            <th>عنوان</th>
                            <th>لینک</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                        </thead>
                        <tbody id="sortable-list">
                        <?php
                            $counter = ($data->currentPage() - 1) * $data->perPage() + 1;
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-id="<?php echo e($item->id); ?>" class="sortable-item">
                                <th scope="row"><?php echo e($counter); ?></th>
                                <td>
                                    <img src="<?php echo e(asset($item->image)); ?>" width="80" height="80" alt="portfolio">
                                </td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->slug); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($item->status): ?>
                                        <button wire:click="change_status(<?php echo e($item->id); ?>)" type="button" class="btn btn-outline-success btn-border-radius">فعال</button>
                                    <?php else: ?>
                                        <button wire:click="change_status(<?php echo e($item->id); ?>)" type="button" class="btn btn-outline-danger btn-border-radius">غیرفعال</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <a href="<?php echo e(route('service.update',$item->id)); ?>"><button class="btn tblActnBtn">
                                            <i class="material-icons">mode_edit</i>
                                        </button></a>
                                    <button wire:click="delete(<?php echo e($item->id); ?>)" class="btn tblActnBtn">
                                        <i class="material-icons">delete</i>
                                    </button>
                                </td>
                            </tr>
                            <?php ($counter++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        </tbody>

                    </table>

                    <div class="row mt-5 ">
                        <div class="col-lg-2 col-sm-4">
                            <div wire:ignore class="input-field col s12 mb-10">
                                <select wire:model.lazy="paginate_count">
                                    <option value="20">صفحه بندی</option>
                                    <option value="50000">نمایش همه</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-5 col-sm-4">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('dashboard/js/form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/multiselect/js/jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/pages/forms/advanced-form-elements.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/Sortable.min.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var el = document.getElementById('sortable-list');
            var sortable = Sortable.create(el, {
                animation: 150,
                handle: '.sortable-item',
                onEnd: function (evt) {
                    var tasks=document.getElementsByClassName("sortable-item");
                    var data=[];
                    for ( i=0;i<tasks.length;i++){
                        data.push(tasks[i].dataset.id);
                    }
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('sort',data,true);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH G:\Laravel Projects\StartWebOne\resources\views/livewire/dashboard/service/index.blade.php ENDPATH**/ ?>