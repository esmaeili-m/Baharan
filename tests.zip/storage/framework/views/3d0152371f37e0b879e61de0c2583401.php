<div class="shop-category" >
    <!--[if BLOCK]><![endif]--><?php if($category): ?>
        <div class="text-center">
            <span class="category-product card-product-title"><?php echo e($category->title); ?></span>
        </div>
        <div class="row mt-3">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div  class="col-lg-6 col-sm-12">
                    <div class="card-category mb-2">
                        <img class="w-100 category-image" src="<?php echo e(asset($product->image ?? '/home/images/category.jpg')); ?>" title="<?php echo e($product->title); ?>" alt="<?php echo e($product->title); ?>">
                        <div class="card-category-content">
                            <div class="d-flex mb-2">
                                <p class="category-product card-category-title mb-0 "><?php echo e($product->name); ?></p>
                                <span wire:loading.class.add="d-none" wire:click="add_to_basket(<?php echo e($product->id); ?>)" class="category-product checkout-button" style="">سفارش <i class="fa fa-arrow-left"></i></span>
                                <div wire:loading style="margin-right: auto;color: #72baf6" class="spinner-grow " role="status">
                                    <span class="sr-only">Loading...</span>
                                </div>
                            </div>
                            <div class="details-product d-flex">
                                <div class="text-center">
                                    <p class="category-product card-product-details w-80 mb-0 "> قیمت محصول: <?php echo e(number_format($product->price)); ?> </p>
                                    <p class="category-product card-product-details mb-0 w-80 "> موجودی انبار: <?php echo e(number_format($product->stock)); ?> </p>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/shop/product.blade.php ENDPATH**/ ?>