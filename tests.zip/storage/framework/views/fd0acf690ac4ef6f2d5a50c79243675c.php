<!DOCTYPE html>
<html lang="en">
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.auth.configs.head', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2919541076-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<body>
<?php echo e($slot); ?>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.auth.configs.foot', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2919541076-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/layouts/home.blade.php ENDPATH**/ ?>