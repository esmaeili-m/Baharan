<div>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <title>آتریو - قالب بوت استرپ 4 مدیریتی </title>
        <link rel="icon" href="<?php echo e(asset('dashboard/images/favicon.ico')); ?>" type="image/x-icon">
        <?php echo $__env->yieldPushContent('styles'); ?>
            <link href="<?php echo e(asset('dashboard/css/app.min.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('dashboard/js/bundles/materialize-rtl/materialize-rtl.min.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('dashboard/css/style.css')); ?>" rel="stylesheet" />
            <link href="<?php echo e(asset('dashboard/css/styles/all-themes.css')); ?>" rel="stylesheet" />
            <link href="<?php echo e(asset('dashboard/css/custom.css')); ?>" rel="stylesheet" />
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <style>

    </style>
</div>
<?php /**PATH G:\Laravel Projects\StartWebOne\resources\views/livewire/dashboard/configs/head.blade.php ENDPATH**/ ?>