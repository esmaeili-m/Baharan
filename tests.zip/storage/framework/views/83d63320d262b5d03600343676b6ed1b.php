<div>
    <script src="<?php echo e(asset('dashboard/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/pages/index.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('dashboard/js/sweetalert2@11')); ?>"></script>
    <script>
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('alert', (event) => {
                const Toast = Swal.mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: event.icon,
                    title: event.message
                });
            });

        })
    </script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


</div>
<?php /**PATH G:\Laravel Projects\StartWebOne\resources\views/livewire/dashboard/configs/foot.blade.php ENDPATH**/ ?>