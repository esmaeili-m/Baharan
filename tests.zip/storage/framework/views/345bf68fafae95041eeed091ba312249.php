<div>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <a href="<?php echo e(route('service.create')); ?>"><button class="btn-hover btn-border-radius color-7 border-radius-custom">افزودن سرویس</button></a>
                    <a href="<?php echo e(route('service.list')); ?>"><button class="btn-hover btn-border-radius color-8 border-radius-custom">بازگشت</button></a>
                </div>
                <div class="body table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>تصویر</th>
                            <th>عنوان</th>
                            <th>لینک</th>
                            <th>عملیات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php ($counter=1); ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($counter); ?></th>
                                <td>
                                    <img src="<?php echo e(asset($item->image)); ?>" width="80" height="80" alt="portfolio">
                                </td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->slug); ?></td>
                                <td>

                                    <button wire:click="restore(<?php echo e($item->id); ?>)" class="btn tblActnBtn">
                                        <i class="material-icons">restore</i>
                                    </button>
                                    <button wire:click="delete(<?php echo e($item->id); ?>)" class="btn tblActnBtn">
                                        <i class="material-icons">delete</i>
                                    </button>
                                </td>
                            </tr>
                            <?php ($counter++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH G:\Laravel Projects\StartWebOne\resources\views/livewire/dashboard/service/trash.blade.php ENDPATH**/ ?>