<div class="sidebar-category" >
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-category mb-2">
            <img class="w-100 category-image" src="<?php echo e(asset($category->image ?? '/home/images/category.jpg')); ?>" title="<?php echo e($category->title); ?>" alt="<?php echo e($category->title); ?>">
            <div class="card-category-content">
                <div class="d-flex mb-2">
                    <p class="category-product card-category-title mb-0 "><?php echo e($category->title); ?></p>
                    <span wire:loading.remove wire:click="set_category(<?php echo e($category->id); ?>)" class="category-product checkout-button" style="">محصولات <i class="fa fa-arrow-left"></i></span>
                    <div wire:loading style="margin-right: auto;color: #72baf6" class="spinner-grow " role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="category-product"><?php echo e($product->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/shop/category.blade.php ENDPATH**/ ?>