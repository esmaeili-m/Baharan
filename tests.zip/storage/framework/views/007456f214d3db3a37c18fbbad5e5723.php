<!DOCTYPE html>
<html lang="en">
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.configs.head', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1323689488-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<body class="light rtl">
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.configs.header', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1323689488-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.configs.header', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1323689488-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.configs.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1323689488-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<section class="content">
    <div class="container-fluid">
        <?php echo e($slot); ?>

    </div>
</section>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.configs.foot', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1323689488-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</body>
<?php /**PATH G:\Laravel Projects\Exam\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>