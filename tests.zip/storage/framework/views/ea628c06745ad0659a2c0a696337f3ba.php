<div>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo e(asset('home/login/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
        <link rel="stylesheet" href="<?php echo e(asset('home/login/style.css')); ?>">
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/auth/configs/head.blade.php ENDPATH**/ ?>