<div>
test
</div>
<?php /**PATH G:\Laravel Projects\Exam\resources\views/livewire/dashboard/index.blade.php ENDPATH**/ ?>