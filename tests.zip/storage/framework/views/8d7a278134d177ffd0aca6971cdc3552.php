<div>
    <script src="<?php echo e(asset('dashboard/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/pages/index.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/sweetalert2@1')); ?>"></script>
    <script>
        document.addEventListener('livewire:initialized', () => {
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "Signed in successfully"
            });
        })
    </script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


</div>
<?php /**PATH G:\Laravel Projects\Exam\resources\views/livewire/dashboard/configs/foot.blade.php ENDPATH**/ ?>