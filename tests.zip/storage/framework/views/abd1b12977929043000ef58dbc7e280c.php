<div >
    <div   class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
         aria-labelledby="formModal" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="formModal">افزودن تگ</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit="save()">
                        <label for="email_address1"> عنوان تگ</label>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" wire:model.lazy="title" id="email_address1" class="form-control "
                                       placeholder="عنوان تگ خود را وارد کنید">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <label for="password">لینک</label>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" wire:model.lazy="link" id="password" class="form-control"
                                       placeholder="لینک خود را وارد کنید">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  type="submit" class="btn btn-info waves-effect">ذخیره</button>
                            <button wire:click="close" id="close_modal" type="button" class="btn btn-danger waves-effect"
                                    data-dismiss="modal">لغو</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('close_modal', (event) => {
                document.getElementById('close_modal').click();
            });
        });
    </script>
    <script>


    </script>
</div>
<?php /**PATH G:\Laravel Projects\StartWebOne\resources\views/livewire/dashboard/tag/components/create-modal.blade.php ENDPATH**/ ?>