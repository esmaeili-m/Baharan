<div>
    <div class="profile-container">
        <div class="row" style="direction: rtl">
            <div class="col-lg-3 col-sm-12">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.profile.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1948200936-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="col-lg-9 col-sm-12">
                <!--[if BLOCK]><![endif]--><?php if($status==1): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.profile.user-information', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1948200936-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php elseif($status==3): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.profile.invoices', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1948200936-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/profile/index.blade.php ENDPATH**/ ?>