<div>
    <!--[if BLOCK]><![endif]--><?php if($submit_information): ?>
        <div class="form-container">
            <div class=" wrapper-register" style="direction: rtl">
                <div class="text-center mb-5">
                    <span class=" btn custom-primary mt-3 mb-3 w-lg-40 w-sm-100 h-sm-50" >شرکت طیور متحد زرین قم (بهاران)</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php if($user->status == 2): ?>
                    <div class=" col-lg-12 col-sm-12">
                        <div class="custom-card d-flex justify-content-center align-items-center" style="background-color: #45c159">
                            <p class="mb-0 fs-sm-20">«کاربر گرامی، اطلاعات شما بررسی و تأیید شد لطفا    وجه ضمانت خود را از طریق لینک زیر پرداخت کنید.»</p>

                        </div>

                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input type="text" wire:model.lazy="name" class="" placeholder="نام و نام خانوادگی*"
                                       <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center <?php $__errorArgs = ['father'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input type="text" wire:model.lazy="father" class="" placeholder="نام پدر*"
                                       <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['father'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['father'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div
                                class="form-field d-flex align-items-center <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mb-sm-10 form-controller-custom">
                                <input type="text" wire:model.lazy="phone" placeholder="شماره همراه*"
                                       <?php if($user): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input type="text" wire:model.lazy="address" class="" placeholder="آدرس*"
                                       <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center <?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input type="text" wire:model.lazy="license_number" class=""
                                       placeholder="شماره پروانه / مجوز*"
                                       <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center <?php $__errorArgs = ['code_meli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input type="text" wire:model.lazy="code_meli" class="" placeholder="کد ملی*"
                                       <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code_meli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code_meli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4 ">
                            <div class="p-3 form-field align-items-center padding-mobile-4 <?php if($errors->has('day')): ?> invalid-form <?php elseif($errors->has('month')): ?> invalid-form <?php elseif($errors->has('years')): ?> invalid-form <?php endif; ?>">
                                <p class="mb-2 " ></p>
                                <button style="font-size: 10px" type="submit" class="btn  custom-label  mx-2  ">
                                    تاریخ تولد
                                </button>
                                <div class=" d-lg-flex">
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="day" id="customSelect">
                                            <option value="0" selected>روز تولد</option>
                                            <!--[if BLOCK]><![endif]--><?php for($i=1;$i<31;$i++): ?>
                                                <!--[if BLOCK]><![endif]--><?php if($i<10): ?>
                                                    <option value="0<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                                <?php else: ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="month" id="customSelect">
                                            <option value="0" selected>ماه صدور</option>
                                            <option value="01">فروردین</option>
                                            <option value="02">اردیبهشت</option>
                                            <option value="03">خرداد</option>
                                            <option value="04">تیر</option>
                                            <option value="05">مرداد</option>
                                            <option value="06">شهریور</option>
                                            <option value="07">مهر</option>
                                            <option value="08">آبان</option>
                                            <option value="09">آذر</option>
                                            <option value="10">دی</option>
                                            <option value="11">بهمن</option>
                                            <option value="12">اسفند</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="years" id="customSelect">
                                            <option value="0" selected>سال تولد</option>
                                            <!--[if BLOCK]><![endif]--><?php for($i=1300;$i<1390;$i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if($errors->has('day')): ?>
                                        <span style="font-size: 27px;color: red;margin-right: auto"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php elseif($errors->has('month')): ?>
                                        <span style="font-size: 27px;color: red"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php elseif($errors->has('years')): ?>
                                        <span style="font-size: 27px;color: red"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                </div>

                                <!--[if BLOCK]><![endif]--><?php if($errors->has('day')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('day')); ?></p>

                                <?php elseif($errors->has('month')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('month')); ?></p>

                                <?php elseif($errors->has('years')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('years')); ?></p>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            </div>


                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4 ">
                            <div class="p-3 form-field align-items-center padding-mobile-4 <?php if($errors->has('license_day')): ?> invalid-form <?php elseif($errors->has('license_month')): ?> invalid-form <?php elseif($errors->has('license_years')): ?> invalid-form <?php endif; ?>">
                                <p class="mb-2 " ></p>
                                <button style="font-size: 10px" type="submit" class="btn  custom-label  mx-2  ">تاریخ صدور پروانه کسب
                                </button>
                                <div class=" d-lg-flex">
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="license_day" id="customSelect">
                                            <option value="0" selected>روز صدور</option>
                                            <!--[if BLOCK]><![endif]--><?php for($i=1;$i<31;$i++): ?>
                                                <!--[if BLOCK]><![endif]--><?php if($i<10): ?>
                                                    <option value="0<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                                <?php else: ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="license_month" id="customSelect">
                                            <option value="0" selected>ماه صدور</option>
                                            <option value="01">فروردین</option>
                                            <option value="02">اردیبهشت</option>
                                            <option value="03">خرداد</option>
                                            <option value="04">تیر</option>
                                            <option value="05">مرداد</option>
                                            <option value="06">شهریور</option>
                                            <option value="07">مهر</option>
                                            <option value="08">آبان</option>
                                            <option value="09">آذر</option>
                                            <option value="10">دی</option>
                                            <option value="11">بهمن</option>
                                            <option value="12">اسفند</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 col-sm-12 mb-3 mt-3 me-3">
                                        <select class="form-select no-arrow" wire:model.lazy="license_years" id="customSelect">
                                            <option value="0" selected>سال صدور</option>
                                            <!--[if BLOCK]><![endif]--><?php for($i=1300;$i<1390;$i++): ?>
                                                <option><?php echo e($i); ?></option>
                                            <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if($errors->has('license_day')): ?>
                                        <span style="font-size: 27px;color: red;margin-right: auto"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php elseif($errors->has('license_month')): ?>
                                        <span style="font-size: 27px;color: red"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php elseif($errors->has('license_years')): ?>
                                        <span style="font-size: 27px;color: red"
                                              class="me-2 fa mt-4 fa-times-circle error-message show" aria-hidden="true"></span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                </div>

                                <!--[if BLOCK]><![endif]--><?php if($errors->has('license_day')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('license_day')); ?></p>

                                <?php elseif($errors->has('license_month')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('license_month')); ?></p>

                                <?php elseif($errors->has('license_years')): ?>
                                    <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($errors->first('license_years')); ?></p>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            </div>


                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-lg-flex align-items-center <?php $__errorArgs = ['license_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <input id="license-file" type="file" wire:model.lazy="license_image" class="d-none" placeholder="">
                                <label wire:model.lazy="license_image" id="license-label" for="license-file" >
                                    <span class="w-100 btn custom-primary mt-3 mb-3 h-sm-50">تصویر پروانه کسب را اپلود کنید</span>
                                </label>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['license_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                <!--[if BLOCK]><![endif]--><?php if($license_image): ?>
                                    <div class="w-sm-100">
                                        <img class="avatar mb-3 mt-3 mx-2" src="<?php echo e(asset($license_image)); ?>" width="120px"
                                             height="120px">

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-lg-flex align-items-center ">
                                <input id="image-file" type="file" wire:model.lazy="avatar" class="d-none" placeholder="">
                                <label wire:model.lazy="avatar" id="image-label" for="image-file">
                                    <span class="w-100 btn custom-primary mt-3 mb-3">تصویر خود را اپلود کنید</span>
                                </label>
                                <!--[if BLOCK]><![endif]--><?php if($avatar): ?>
                                    <div class="w-sm-100">
                                        <img class="avatar mb-3 mt-3 mx-2" src="<?php echo e(asset($avatar)); ?>" width="120px"
                                             height="120px">

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 mb-4">
                            <div class="form-field d-flex align-items-center p-2 <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-form <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                <div class="w-100 d-flex">
                                    <button  wire:click="set_type('مالک')"  type="submit" class="btn w-lg-50 w-sm-100 custom-<?php echo e($type == 'مالک' ? 'green' : 'primary'); ?> mt-3 mb-3 mx-2 ">مالک
                                    </button>
                                    <button wire:click="set_type('استیجاری')" type="submit" class="btn w-lg-50 w-sm-100 custom-<?php echo e($type == 'استیجاری' ? 'green' : 'primary'); ?> mt-3 mb-3">استیجاری
                                    </button>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="font-size: 27px;color: red" class="fa fa-times-circle error-message show"
                                      aria-hidden="true"></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="font-size: 12px" class="me-2 text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="custom-card d-flex justify-content-center align-items-center ">
                                        <p class="mb-0 fs-sm-20">«کاربر گرامی، اطلاعات شما در حال بررسی و تأیید است.»</p>

                            </div>

                        </div>
                        <div class="col-lg-2 col-sm-12">
                            <!--[if BLOCK]><![endif]--><?php if($user): ?>
                                <button style="width: 100%" wire:click="user_update()" type="submit"
                                        class="btn custom-primary mt-3 mb-3"
                                        <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?> >ثبت اطلاعات
                                </button>
                            <?php else: ?>
                                <button style="width: 100%" wire:click="register_user()" type="submit"
                                        class="btn custom-primary mt-3 mb-3"
                                        <?php if(($user->status ?? 0) == 2): ?> disabled <?php endif; ?> >ثبت اطلاعات
                                </button>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                    </div>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
    <?php else: ?>
        <div class="wrapper">
            <div class="logo">
                <img src="https://www.freepnglogos.com/uploads/twitter-logo-png/twitter-bird-symbols-png-logo-0.png"
                     alt="">
            </div>
            <div class="text-center mt-3 name mb-4">
                <p>فرم ثبت نام</p>
            </div>
            <!--[if BLOCK]><![endif]--><?php if($status): ?>
                <div>
                    <p class="mb-1" style="direction: rtl; font-size: 12px;color: #acacac">کد ارسال شده به شماره همراه
                        : <?php echo e($phone); ?></p>
                    <div class="form-field d-flex align-items-center">
                        <span class="fa fa-barcode"></span>
                        <input type="text" wire:model.lazy="code" placeholder="کد 5 رقمی*">

                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="direction: rtl; font-size: 13px" class=" text-danger mb-0"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if(session('code')): ?>
                        <p style="direction: rtl; font-size: 13px" class=" text-danger mb-0"><?php echo e(session('code')); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <button wire:click="check_code()" type="submit" class="btn mt-3 mb-3">ارسال اطلاعات</button>
                </div>
            <?php else: ?>
                <div>
                    <div class="form-field d-flex align-items-center">
                        <span class="fa fa-phone"></span>
                        <input type="text" wire:model.lazy="phone" id="phone" placeholder="شماره همراه*">

                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="direction: rtl; font-size: 13px" class=" text-danger mb-0"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <button wire:click="get_code()" type="submit" class="btn mt-3 mb-3">ارسال اطلاعات</button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="text-center fs-6">
                <span style="color: #7f7f7f;font-size: 13px">شرکت طیور متحد زرین قم (بهاران)</span>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/home/auth/login.blade.php ENDPATH**/ ?>