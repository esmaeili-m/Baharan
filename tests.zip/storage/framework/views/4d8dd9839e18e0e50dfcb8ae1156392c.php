<div>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('dashboard/js/bundles/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/js/bundles/multiselect/css/multi-select.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <a href="<?php echo e(route('user.create')); ?>"><button class="btn-hover btn-border-radius color-7 border-radius-custom">افزودن کاربر</button></a>
                    <a href="<?php echo e(route('user.list')); ?>"><button class="btn-hover btn-border-radius color-8 border-radius-custom">بازگشت</button></a>
                </div>
                <div class="row mt-3 mx-2">
                    <div class="col-2">
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text"
                                       wire:model.defer="name"
                                       class="form-control"
                                       placeholder="نام کاربر را وارد کنید">
                            </div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text"
                                       wire:model.defer="phone"
                                       class="form-control"
                                       placeholder="شماره کاربر را وارد کنید">
                            </div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text"
                                       wire:model.defer="code_meli"
                                       class="form-control"
                                       placeholder="کدملی کاربر را وارد کنید">
                            </div>
                        </div>
                    </div>
                    <div class="col-2">
                        <div wire:ignore class="select2 input-field col s12">
                            <select wire:model.defer="role_id">
                                <option value="" disabled >نقش ها</option>
                                <option value="0" selected>همه</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Role::where('status',1)->pluck('title','id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                    </div>
                    <div class="col-2">
                        <div wire:ignore class="select2 input-field col s12">
                            <select wire:model.defer="status">
                                <option value="" disabled >وضعیت کاربر</option>
                                <option value="0" selected> همه</option>
                                <option value="1">عدم تایید</option>
                                <option value="2">درانتضار تایید نهایی</option>
                                <option value="3">تایید شده</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-2">
                        <div wire:loading.remove class="btn-group " role="group">
                            <button wire:click="fillter()"  style="height: 55px;border-radius-: 5px" class="btn btn-outline-info"><i class="fa fa-search"></i></button>
                            <button wire:click="reset_search()" type="button" style="height: 55px;border-radius: 5px" class="btn btn-outline-warning"><i class="fa fa-times"></i></button>

                        </div>
                        <div wire:loading class="spinner-grow text-warning" style="width: 3rem; height: 3rem;" role="status"></div>

                    </div>
                </div>
                <div class="body table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>نام</th>
                            <th>شماره</th>
                            <th>کدملی</th>
                            <th>نقش</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                        </thead>
                        <tbody >
                        <?php
                            $counter = ($data->currentPage() - 1) * $data->perPage() + 1;
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <th scope="row"><?php echo e($counter); ?></th>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td><?php echo e($item->code_meli); ?></td>
                                <td><?php echo e($item->role->title ?? 'Unknow'); ?></td>

                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($item->status == 1): ?>
                                        <button  type="button" class="btn btn-outline-danger btn-border-radius">عدم تایید</button>
                                    <?php elseif($item->status == 2): ?>
                                        <button  type="button" class="btn btn-outline-warning btn-border-radius">درانتظار تایید</button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-outline-success btn-border-radius">تایید شده</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>

                                    <button wire:click="restore(<?php echo e($item->id); ?>)" class="btn tblActnBtn">
                                        <i class="material-icons">restore</i>
                                    </button>
                                    <button wire:click="delete(<?php echo e($item->id); ?>)" class="btn tblActnBtn">
                                        <i class="material-icons">delete</i>
                                    </button>
                                </td>
                            </tr>
                            <?php ($counter++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>

                    <div class="row mt-5 ">
                        <div class="col-lg-2 col-sm-4">
                            <div wire:ignore class="input-field col s12 mb-10">
                                <select wire:model.lazy="paginate_count">
                                    <option value="20">صفحه بندی</option>
                                    <option value="50000">نمایش همه</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-5 col-sm-4">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('dashboard/js/form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/multiselect/js/jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/pages/forms/advanced-form-elements.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php /**PATH G:\Laravel Projects\Baharan\resources\views/livewire/dashboard/users/trash.blade.php ENDPATH**/ ?>