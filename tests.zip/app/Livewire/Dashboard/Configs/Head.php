<?php

namespace App\Livewire\Dashboard\Configs;

use Livewire\Component;

class Head extends Component
{
    public function render()
    {
        return view('livewire.dashboard.configs.head');
    }
}
