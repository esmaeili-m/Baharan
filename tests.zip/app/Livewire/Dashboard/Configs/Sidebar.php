<?php

namespace App\Livewire\Dashboard\Configs;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.dashboard.configs.sidebar');
    }
}
