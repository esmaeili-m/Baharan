<?php

namespace App\Livewire\Dashboard\Configs;

use Livewire\Component;

class Foot extends Component
{
    public function render()
    {
        return view('livewire.dashboard.configs.foot');
    }
}
