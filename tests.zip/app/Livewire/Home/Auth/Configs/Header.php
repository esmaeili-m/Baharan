<?php

namespace App\Livewire\Home\Auth\Configs;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.home.auth.configs.header');
    }
}
