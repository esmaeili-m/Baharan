<?php

namespace App\Livewire\Home\Profile;

use Livewire\Component;

class Sidebar extends Component
{
    public function change_status($status)
    {

    }
    public function render()
    {
        return view('livewire.home.profile.sidebar');
    }
}
